/* write your SQL and answers */
/* Execution of various SQL commands based on Autism dataset: */

/*     How many middle eastern children show ASD traits ? */

/*     How many children who have Jaundice show ASD traits ? */

/*     Are ASD traits dependent on hereditary ? Justify . */

/*     People of which ethnicity are most likely to exhibit ASD traits ? */

/*     What is the proportion of a white European girls (female) exhibit ASD traits among all white European girls? */

